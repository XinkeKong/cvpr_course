import numpy as np
import matplotlib.pyplot as plt
import torch
from sklearn.datasets import make_s_curve
import torch.nn as nn



## 创建一种分布的数据，这里以S型数据为例
def make_data():
    s_curve, _ = make_s_curve(10**4, noise=0.1)
    s_curve = s_curve[:,[0,2]]/10.0
    data = s_curve.T
    #可视化显示
    fig, ax = plt.subplots()
    ax.scatter(*data, color='red', edgecolor='white')
    ax.axis('off')
    dataset = torch.Tensor(s_curve).float()
    plt.savefig('source-data.png')
    plt.show()
    return dataset


#前向加噪函数
def q_x(x_0, t, alphas_bar_sqrt, one_minus_alphas_bar_sqrt):
    # 超参数设置
    noise = torch.randn_like(x_0)
    alphas_t = alphas_bar_sqrt[t]
    alphas_l_m_t = one_minus_alphas_bar_sqrt[t]

    return alphas_t * x_0 + alphas_l_m_t * noise


# 画图 0-T步，均匀抽取出20个步数的加噪结果，打印
def plt_noise_data(dataset, alphas_bar_sqrt, one_minus_alphas_bar_sqrt, num_shows=20, num_steps=100):
    fig, axs = plt.subplots(2, 10, figsize=(28,3))
    plt.rc('text', color='blue')

    for i in range(num_shows):
        j = i//10
        k = i%10
        q_i = q_x(dataset, torch.tensor([i*num_steps//num_shows]), alphas_bar_sqrt, one_minus_alphas_bar_sqrt)
        axs[j, k].scatter(q_i[:,0], q_i[:,1], color='red', edgecolor='white')
        axs[j, k].set_axis_off()
        axs[j, k].set_title('$q(\mathbf{x}_{'+str(i*num_steps//num_shows)+'})$')

    plt.savefig('noise-data.png')
    plt.show()
    return


#设计你的 MLP 网络架构
class MLPDiffusion(nn.Module):
    def __init__(self, n_steps, num_units=128):
        super(MLPDiffusion, self).__init__()


    def forward(self, x, t):

        return x

# 编写你的损失函数
def diffusion_loss_fn(model, x, alphas_bar_sqrt, one_minus_alphas_bar_sqrt, n_steps):

    return 

#采样
def p_sample(model_, x_, t_, betas_, one_minus_alphas_bar_sqrt_):
    t_ = torch.tensor([t_])
    coeff = betas_[t_] / one_minus_alphas_bar_sqrt_[t_]
    eps_theta = model_(x_, t_)
    mean = (1 / (1-betas_[t_]).sqrt()) * (x_ - coeff * eps_theta)
    z = torch.randn_like(x_)
    sigma_t = betas_[t_].sqrt()
    sample = mean + sigma_t*z

    return sample


def p_sample_loop(model_, shape, n_steps, betas_, one_minus_alphas_bar_sqrt_):
    cur_x = torch.randn(shape)
    # cur_x[0, 0] = 0.4735   # -0.0381, 0.0173     -0.0481  0.0277    0.0435  0.1910
    # cur_x[0, 1] = 0.7676
    x_seq = [cur_x]
    for i in reversed(range(n_steps)):
        cur_x = p_sample(model_, cur_x, i, betas_, one_minus_alphas_bar_sqrt_)
        x_seq.append(cur_x)

    return x_seq


# 如果有训练好的模型，加载模型
def load_model(model_, pth):
    checkpoint = torch.load(pth, map_location='cpu')
    checkpoint_model = checkpoint['model']
    msg = model_.load_state_dict(checkpoint_model, strict=False)
    print(msg)
    return


if __name__ == "__main__":
    # 考虑设计以下超参数
    batch_size = 128
    num_epoch = 4000 # 训练总次数
    num_steps = 100  # T步数
    print_frequency = 500  #每多少个epoch，采样测试一次，并打印结果

    # 固定参数
    betas_1 = torch.linspace(-6, 6, num_steps)
    betas_2 = torch.sigmoid(betas_1)
    betas = betas_2 * (0.5e-2 - 1e-5) + 1e-5
    alphas = 1 - betas
    alphas_prod = torch.cumprod(alphas, 0)
    alphas_prod_p = torch.cat([torch.tensor([1]).float(), alphas_prod[:-1]], 0)
    alphas_bar_sqrt = torch.sqrt(alphas_prod)
    one_minus_alphas_bar_log = torch.log(1 - alphas_prod)
    one_minus_alphas_bar_sqrt = torch.sqrt(1 - alphas_prod)


    dataset = make_data()
    plt_noise_data(dataset, alphas_bar_sqrt, one_minus_alphas_bar_sqrt, num_shows=20, num_steps=num_steps)
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)
    plt.rc('text', color='blue')

    model = MLPDiffusion(num_steps)
    # load_model(model, 'test.pth')
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    for t in range(num_epoch):
        for idx, batch_x in enumerate(dataloader):

            loss = diffusion_loss_fn(model, batch_x, alphas_bar_sqrt, one_minus_alphas_bar_sqrt, num_steps)
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()

        if (t+1) % print_frequency == 0:
            x_seq = p_sample_loop(model, dataset.shape, num_steps, betas, one_minus_alphas_bar_sqrt)
            fig, axs = plt.subplots(1, 10, figsize=(28, 3))
            for i in range(1, 11):
                cur_x = x_seq[i * 10].detach()
                axs[i - 1].scatter(cur_x[:,0], cur_x[:, 1], color='red',  edgecolor='white')
                axs[i - 1].set_axis_off()
                axs[i - 1].set_title('$q(\mathbf{x}_{'+str(i*10)+'})$')
            plt.savefig('sampling-at-' + str(t) + '-epoch.png')
            #plt.show()
            print('epoch: ' + str(t) + '   ' + str(loss))

    # torch.save({'model':model.state_dict()}, 'test.pth')
    print('finish')